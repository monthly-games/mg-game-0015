import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:mg_common_game/systems/gacha/gacha_pool.dart';
import 'package:mg_common_game/systems/gacha/gacha_manager.dart';
import 'package:mg_common_game/systems/quests/daily_quest.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:get_it/get_it.dart';
import 'package:mg_common_game/core/audio/audio_manager.dart';
import 'package:mg_common_game/core/ui/theme/app_colors.dart';
import 'package:mg_common_game/core/ui/theme/app_text_styles.dart';
import 'package:mg_common_game/systems/systems.dart';
import 'features/resources/resource_manager.dart';
// import 'features/buildings/building_data.dart';
import 'features/buildings/building_definition.dart';
import 'features/buildings/building_instance.dart';
import 'features/ui/construction_overlay.dart';
import 'features/ui/tutorial_overlay.dart';
import 'game/kingdom_game.dart';
import 'package:mg_common_game/systems/progression/prestige_manager.dart';
import 'screens/gacha_screen.dart';
import 'screens/daily_quest_screen.dart';
import 'screens/achievement_screen.dart';
import 'screens/battlepass_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _setupDI();
  await GetIt.I<AudioManager>().initialize();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ResourceManager()),
        ChangeNotifierProvider.value(value: GetIt.I<CollectionManager>()),
      ],
      child: const KingdomApp(),
    ),
  );
}

// Screen route names for retention UI navigation
const _kGachaRoute = '/gacha';
const _kDailyQuestsRoute = '/daily-quests';

void _setupDI() {
  if (!GetIt.I.isRegistered<AudioManager>()) {
    GetIt.I.registerSingleton<AudioManager>(AudioManager());
  }
  if (!GetIt.I.isRegistered<CollectionManager>()) {
    final collectionManager = CollectionManager();
    _registerCollections(collectionManager);
    GetIt.I.registerSingleton<CollectionManager>(collectionManager);
  // DailyQuest 시스템
  GetIt.I.registerSingleton(DailyQuestManager());
  // Gacha 시스템
  GetIt.I.registerSingleton(GachaManager());

  // Prestige 시스템 (mg_common_game)
  if (!GetIt.I.isRegistered<PrestigeManager>()) {
    final prestigeManager = PrestigeManager();
    GetIt.I.registerSingleton(prestigeManager);
    _setupPrestige(prestigeManager);
  }
  _setupGacha();
  _registerDailyQuests();
  }
}

void _registerCollections(CollectionManager manager) {
  // Register buildings collection
  manager.registerCollection(
    'buildings_collection',
    [
      CollectibleItem(
        id: 'building_castle',
        name: 'Castle',
        rarity: CollectibleRarity.legendary,
        metadata: {'type': 'castle'},
      ),
      CollectibleItem(
        id: 'building_lumber_mill',
        name: 'Lumber Mill',
        rarity: CollectibleRarity.common,
        metadata: {'type': 'lumberMill'},
      ),
      CollectibleItem(
        id: 'building_stone_quarry',
        name: 'Stone Quarry',
        rarity: CollectibleRarity.common,
        metadata: {'type': 'stoneQuarry'},
      ),
      CollectibleItem(
        id: 'building_house',
        name: 'House',
        rarity: CollectibleRarity.common,
        metadata: {'type': 'house'},
      ),
    ],
  );

  // Register gacha collection (16 items)
  manager.registerCollection(
    'gacha_collection',
    [
      // UR → mythic (2 items)
      CollectibleItem(
        id: 'ur_kingdom_001',
        name: '전설의 Building',
        rarity: CollectibleRarity.mythic,
        metadata: {'gacha_rarity': 'UR'},
      ),
      CollectibleItem(
        id: 'ur_kingdom_002',
        name: '신화의 Building',
        rarity: CollectibleRarity.mythic,
        metadata: {'gacha_rarity': 'UR'},
      ),
      // SSR → legendary (3 items)
      CollectibleItem(
        id: 'ssr_kingdom_001',
        name: '영웅의 Building',
        rarity: CollectibleRarity.legendary,
        metadata: {'gacha_rarity': 'SSR'},
      ),
      CollectibleItem(
        id: 'ssr_kingdom_002',
        name: '고대의 Building',
        rarity: CollectibleRarity.legendary,
        metadata: {'gacha_rarity': 'SSR'},
      ),
      CollectibleItem(
        id: 'ssr_kingdom_003',
        name: '황금의 Building',
        rarity: CollectibleRarity.legendary,
        metadata: {'gacha_rarity': 'SSR'},
      ),
      // SR → epic (4 items)
      CollectibleItem(
        id: 'sr_kingdom_001',
        name: '희귀한 Building A',
        rarity: CollectibleRarity.epic,
        metadata: {'gacha_rarity': 'SR'},
      ),
      CollectibleItem(
        id: 'sr_kingdom_002',
        name: '희귀한 Building B',
        rarity: CollectibleRarity.epic,
        metadata: {'gacha_rarity': 'SR'},
      ),
      CollectibleItem(
        id: 'sr_kingdom_003',
        name: '희귀한 Building C',
        rarity: CollectibleRarity.epic,
        metadata: {'gacha_rarity': 'SR'},
      ),
      CollectibleItem(
        id: 'sr_kingdom_004',
        name: '희귀한 Building D',
        rarity: CollectibleRarity.epic,
        metadata: {'gacha_rarity': 'SR'},
      ),
      // R → rare (5 items)
      CollectibleItem(
        id: 'r_kingdom_001',
        name: '우수한 Building A',
        rarity: CollectibleRarity.rare,
        metadata: {'gacha_rarity': 'R'},
      ),
      CollectibleItem(
        id: 'r_kingdom_002',
        name: '우수한 Building B',
        rarity: CollectibleRarity.rare,
        metadata: {'gacha_rarity': 'R'},
      ),
      CollectibleItem(
        id: 'r_kingdom_003',
        name: '우수한 Building C',
        rarity: CollectibleRarity.rare,
        metadata: {'gacha_rarity': 'R'},
      ),
      CollectibleItem(
        id: 'r_kingdom_004',
        name: '우수한 Building D',
        rarity: CollectibleRarity.rare,
        metadata: {'gacha_rarity': 'R'},
      ),
      CollectibleItem(
        id: 'r_kingdom_005',
        name: '우수한 Building E',
        rarity: CollectibleRarity.rare,
        metadata: {'gacha_rarity': 'R'},
      ),
      // N → common (6 items)
      CollectibleItem(
        id: 'n_kingdom_001',
        name: '일반 Building A',
        rarity: CollectibleRarity.common,
        metadata: {'gacha_rarity': 'N'},
      ),
      CollectibleItem(
        id: 'n_kingdom_002',
        name: '일반 Building B',
        rarity: CollectibleRarity.common,
        metadata: {'gacha_rarity': 'N'},
      ),
      CollectibleItem(
        id: 'n_kingdom_003',
        name: '일반 Building C',
        rarity: CollectibleRarity.common,
        metadata: {'gacha_rarity': 'N'},
      ),
      CollectibleItem(
        id: 'n_kingdom_004',
        name: '일반 Building D',
        rarity: CollectibleRarity.common,
        metadata: {'gacha_rarity': 'N'},
      ),
      CollectibleItem(
        id: 'n_kingdom_005',
        name: '일반 Building E',
        rarity: CollectibleRarity.common,
        metadata: {'gacha_rarity': 'N'},
      ),
      CollectibleItem(
        id: 'n_kingdom_006',
        name: '일반 Building F',
        rarity: CollectibleRarity.common,
        metadata: {'gacha_rarity': 'N'},
      ),
    ],
  );
}

class KingdomApp extends StatelessWidget {
  const KingdomApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kingdom Rebuild',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: AppColors.background,
        primaryColor: AppColors.primary,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          brightness: Brightness.dark,
        ),
      ),
      home: const KingdomScreen(),
      routes: {
        '/gacha': (_) => const GachaScreen(),
        '/daily-quests': (_) => const DailyQuestScreen(),
          '/daily_quest': (_) => const DailyQuestScreen(),
          '/achievement': (_) => const AchievementScreen(),
          '/battlepass': (_) => const BattlePassScreen(),
        },
    );
  }
}

class KingdomScreen extends StatefulWidget {
  const KingdomScreen({super.key});

  @override
  State<KingdomScreen> createState() => _KingdomScreenState();
}

class _KingdomScreenState extends State<KingdomScreen> {
  // We need to access the provider to pass it to the game instance
  // Or we can let the Game instance be creating inside build accessing context.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Consumer<ResourceManager>(
        builder: (context, resourceManager, child) {
          return GameWidget(
            game: KingdomGame(resourceManager: resourceManager),
            overlayBuilderMap: {
              'HUD': (BuildContext context, KingdomGame game) {
                return KingdomHud(game: game);
              },
              'construction': (BuildContext context, KingdomGame game) {
                return ConstructionOverlay(
                  game: game,
                  resourceManager: resourceManager,
                  onClose: () {
                    game.overlays.remove('construction');
                    game.overlays.add('HUD');
                  },
                );
              },
              'tutorial': (BuildContext context, KingdomGame game) {
                return TutorialOverlay(
                  onFinish: () {
                    resourceManager.completeTutorial();
                    game.overlays.remove('tutorial');
                  },
                );
              },
            },
            initialActiveOverlays: [
              'HUD',
              if (!resourceManager.tutorialCompleted) 'tutorial',
            ],
          );
        },
      ),
    );
  }
}

class KingdomHud extends StatelessWidget {
  final KingdomGame game;
  const KingdomHud({super.key, required this.game});

  @override
  // ... Inside KingdomHud
  Widget build(BuildContext context) {
    // Consume resource manager to rebuild HUD on change
    return Consumer<ResourceManager>(
      builder: (context, resources, child) {
        // Selection Logic
        final selectedId = resources.selectedBuildingId;
        final selectedBuilding = selectedId != null
            ? resources.buildings.cast<BuildingInstance?>().firstWhere(
                (b) => b?.id == selectedId,
                orElse: () => null,
              )
            : null;

        return SafeArea(
          child: Column(
            children: [
              // 1. Top Resource Bar
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 16,
                ),
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.panel,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.primary),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildResourceItem(
                      Icons.monetization_on,
                      AppColors.secondary,
                      resources.gold,
                    ),
                    _buildResourceItem(
                      Icons.forest,
                      Colors.brown,
                      resources.wood,
                    ),
                    _buildResourceItem(
                      Icons.landscape,
                      Colors.grey,
                      resources.stone,
                    ),
                  ],
                ),
              ),

              const Spacer(),

              // 2. Active Buttons (Floating) - Only if NOT selecting? Or always?
              // Hide Build button if selecting to avoid clutter? No, keep it.
              Padding(
                padding: const EdgeInsets.only(bottom: 20, right: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (selectedBuilding ==
                        null) // Hide controls when inspecting?
                      FloatingActionButton.extended(
                        heroTag: 'build_btn',
                        onPressed: () {
                          try {
                            GetIt.I<AudioManager>().playSfx('sfx_click.wav');
                          } catch (_) {}
                          // Open Construction Overlay
                          // Ideally we pass context or callback.
                          // For now, hack: we know the 'construction' overlay is registered.
                          // But we can't trigger it easily without GameRef.
                          // Wait, in previous step I said I'd fix structure.
                          // KingdomHud has field: final KingdomGame game;
                          // So we CAN use game.overlays!
                          // Step 1188 shows: class KingdomHud extends StatelessWidget { const KingdomHud({super.key}); ...
                          // It lacks the `final KingdomGame game` field in the definition!
                          // But line 74: KingdomHud(game: game) implies it is expected or failed.
                          // Ah, line 74 in `build` passes `game`, but class definition (line 95) does NOT have it.
                          // I must fix that too.

                          // BUT, I can't simple fix constructor in THIS replace block easily if I don't target it.
                          // I am targeting `build`.

                          // I will assume `game` is available if I fix the class def in a separate edit or larger edit.
                          // I'll make this edit assume `this.game` exists and I'll do a second edit to add the field.
                          game.overlays.add('construction');
                          game.overlays.remove('HUD');
                        },
                        icon: const Icon(Icons.construction),
                        label: const Text("Build"),
                        backgroundColor: AppColors.primary,
                      ),
                    const SizedBox(width: 16),
                    FloatingActionButton.extended(
                      heroTag: 'tax_btn',
                      onPressed: () {
                        try {
                          GetIt.I<AudioManager>().playSfx('sfx_coin.wav');
                        } catch (_) {}
                        resources.click();
                      },
                      icon: const Icon(Icons.touch_app),
                      label: const Text("Collect Tax"),
                      backgroundColor: AppColors.secondary,
                    ),
                  ],
                ),
              ),

              // 3. Bottom Panel (Selection or List)
              Container(
                height: 280, // Slightly taller
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: Offset(0, -5),
                    ),
                  ],
                ),
                child: selectedBuilding != null
                    ? _buildInspector(context, resources, selectedBuilding)
                    : _buildBuildingList(context, resources),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInspector(
    BuildContext context,
    ResourceManager resources,
    BuildingInstance b,
  ) {
    final canAfford = resources.canAfford(b.currentCost);
    final isConstructing = b.isUnderConstruction;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Inspect: ${b.name}", style: AppTextStyles.header2),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => resources.selectBuilding(null),
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Icon
                CircleAvatar(
                  radius: 30,
                  backgroundColor: _getBuildingColor(b.type).withOpacity(0.2),
                  child: Icon(
                    _getBuildingIcon(b.type),
                    size: 30,
                    color: _getBuildingColor(b.type),
                  ),
                ),
                const SizedBox(height: 10),
                Text("Level ${b.level}", style: AppTextStyles.header1),
                Text(b.definition.description, style: AppTextStyles.body),
                const Divider(),
                // Upgrade Btn
                ElevatedButton(
                  onPressed: !isConstructing && canAfford
                      ? () {
                          resources.upgradeBuilding(b.id);
                          GetIt.I<AudioManager>().playSfx('sfx_build.wav');
                        }
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                  ),
                  child: Text(
                    isConstructing
                        ? "Upgrading..."
                        : "Upgrade (${b.currentCost.toInt()} G)",
                  ),
                ),
                if (isConstructing)
                  Text(
                    "Time Left: ${b.constructionEndTime!.difference(DateTime.now()).inSeconds}s",
                  ),

                const SizedBox(height: 10),

                // Workers
                if (b.maxWorkers > 0)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove),
                        onPressed: b.workers > 0
                            ? () => resources.removeWorker(b.id)
                            : null,
                      ),
                      Text("Workers: ${b.workers} / ${b.maxWorkers}"),
                      IconButton(
                        icon: const Icon(Icons.add),
                        onPressed:
                            (resources.availableWorkers > 0 &&
                                b.workers < b.maxWorkers)
                            ? () => resources.assignWorker(b.id)
                            : null,
                      ),
                    ],
                  ),

                const Divider(),
                // Demolish
                TextButton.icon(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  label: const Text(
                    "Demolish (50% Refund)",
                    style: TextStyle(color: Colors.red),
                  ),
                  onPressed: () {
                    resources.removeBuilding(b.id);
                    resources.selectBuilding(null);
                    GetIt.I<AudioManager>().playSfx(
                      'sfx_error.wav',
                    ); // Destructive sound?
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBuildingList(BuildContext context, ResourceManager resources) {
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.all(12.0),
          child: Text("Kingdom Overview", style: AppTextStyles.header2),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: resources.buildings.length,
            itemBuilder: (context, index) {
              final b = resources.buildings[index];
              // Just simple list, tap to select
              return ListTile(
                leading: Icon(
                  _getBuildingIcon(b.type),
                  color: _getBuildingColor(b.type),
                ),
                title: Text(b.name),
                subtitle: Text("Lv.${b.level}"),
                onTap: () {
                  resources.selectBuilding(b.id);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildResourceItem(
    IconData icon,
    Color color,
    double amount, {
    bool isInt = false,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(width: 8),
        Text(
          isInt
              ? amount.toInt().toString()
              : amount
                    .toInt()
                    .toString(), // Helper is same for now as amount is floor?
          style: AppTextStyles.header2.copyWith(
            color: AppColors.textHighEmphasis,
          ),
        ),
      ],
    );
  }

  Color _getBuildingColor(BuildingType type) {
    switch (type) {
      case BuildingType.castle:
        return Colors.grey;
      case BuildingType.lumberMill:
        return Colors.brown;
      case BuildingType.stoneQuarry:
        return Colors.blueGrey;
      case BuildingType.house:
        return Colors.orangeAccent;
    }
  }

  IconData _getBuildingIcon(BuildingType type) {
    switch (type) {
      case BuildingType.castle:
        return Icons.security;
      case BuildingType.lumberMill:
        return Icons.forest;
      case BuildingType.stoneQuarry:
        return Icons.landscape;
      case BuildingType.house:
        return Icons.maps_home_work;
    }
  }
}


void _registerDailyQuests() {
  final dailyQuest = GetIt.I<DailyQuestManager>();
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'collect_gold',
    title: '골드 모으기',
    description: '골드 1000 획득',
    targetValue: 1000,
    goldReward: 500,
    xpReward: 10,
  ));
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'play_games',
    title: '게임 플레이',
    description: '게임 5판 플레이',
    targetValue: 5,
    goldReward: 300,
    xpReward: 5,
  ));
  
  dailyQuest.registerQuest(DailyQuest(
    id: 'level_up',
    title: '레벨업',
    description: '레벨 1 상승',
    targetValue: 1,
    goldReward: 200,
    xpReward: 3,
  ));
}


void _setupGacha() {
  final gacha = GetIt.I<GachaManager>();

  gacha.registerPool(GachaPool(
    id: 'standard_pool',
    nameKr: '스탠다드 뽑기',
    items: [
      // N (50%)
      ...List.generate(20, (i) => GachaItem(
        id: 'n_item_$i',
        nameKr: '일반 아이템 $i',
        rarity: GachaRarity.normal,
      )),

      // R (35%)
      ...List.generate(10, (i) => GachaItem(
        id: 'r_item_$i',
        nameKr: '레어 아이템 $i',
        rarity: GachaRarity.rare,
      )),

      // SR (12%)
      ...List.generate(5, (i) => GachaItem(
        id: 'sr_item_$i',
        nameKr: '슈퍼레어 아이템 $i',
        rarity: GachaRarity.superRare,
      )),

      // SSR (2.7%)
      GachaItem(
        id: 'ssr_item_1',
        nameKr: '울트라레어 아이템 1',
        rarity: GachaRarity.ultraRare,
      ),

      // UR (0.3%)
      GachaItem(
        id: 'ur_item_1',
        nameKr: '레전더리 아이템 1',
        rarity: GachaRarity.legendary,
      ),
    ],
  ));
}

void _setupPrestige(PrestigeManager manager) {
  // ── Prestige Upgrades (idle game defaults) ──────────────────
  // Five core upgrades for idle games
  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'gold_multiplier',
    name: '골드 배수',
    description: '골드 획득량 +10%',
    maxLevel: 50,
    costPerLevel: 1,
    bonusPerLevel: 0.1,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'xp_boost',
    name: 'XP 부스트',
    description: 'XP 획득량 +15%',
    maxLevel: 40,
    costPerLevel: 2,
    bonusPerLevel: 0.15,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'production_speed',
    name: '생산 속도',
    description: '생산 속도 +20%',
    maxLevel: 30,
    costPerLevel: 2,
    bonusPerLevel: 0.2,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'starting_resources',
    name: '초기 자원',
    description: '초기 자원 +5%',
    maxLevel: 60,
    costPerLevel: 1,
    bonusPerLevel: 0.05,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'offline_income',
    name: '오프라인 수익',
    description: '오프라인 수익 +20%',
    maxLevel: 30,
    costPerLevel: 3,
    bonusPerLevel: 0.2,
  ));

  // ── Prestige Reset Callbacks ────────────────────────────────
  // TODO: Add game-specific reset callbacks:
  // manager.registerResetCallback(() {
  //   if (GetIt.I.isRegistered<ProgressionManager>()) {
  //     GetIt.I<ProgressionManager>().reset();
  //   }
  //   if (GetIt.I.isRegistered<UpgradeManager>()) {
  //     GetIt.I<UpgradeManager>().reset();
  //   }
  // });
}
